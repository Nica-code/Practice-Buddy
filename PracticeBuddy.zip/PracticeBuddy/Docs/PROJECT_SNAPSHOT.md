PracticeBuddy — Project Snapshot (Day 5)

Purpose

PracticeBuddy is an iOS + iPadOS app to help violinists practice better by tracking practice time, sessions, and notes, with simple goals and streaks. The app includes a theming + typography system to make the UI feel slick, clean, and “music-inspired.” Day 5 focused on polishing typography, stabilizing UI behavior during appearance changes, and simplifying the “Store” direction (store becomes for future feature unlocks only; themes/fonts are free).

⸻

Persistent Rule (Applies to Every Coding Day)

Full-file code rule: Whenever we make changes, ChatGPT must always provide the FULL updated code for every file that needs to be changed (copy-paste ready), not just snippets/diffs.
If a new file must be created, ChatGPT must provide the FULL contents of the new file and the exact path where it should be created.
If a file does not need changes, ChatGPT should not rewrite it.

⸻

Environment
    •    macOS: 26.2 (Build 25C56)
    •    Xcode: 26.2 (Build 17C52)
    •    Runs on: iPhone + iPad (Universal; tested on simulator + real device)
    •    UI: SwiftUI
    •    Language: Swift
    •    Persistence: SwiftData

⸻

Current State (What Works)

App Navigation
    •    Main navigation is a bottom Tab Bar (always present):
    •    Home
    •    History
    •    Friends
    •    Settings
    •    Each tab is wrapped in its own NavigationStack.

Home (Main Dashboard)
    •    Title: “Practice Buddy” (hero title) using the selected font pack.
    •    Compact practice control row:
    •    Status label (Ready / Practicing / Paused)
    •    Live timer (HH:MM:SS)
    •    Start ↔ Pause ↔ Resume, Stop
    •    Save Session sheet:
    •    Optional notes
    •    Discard clears timer state
    •    Save writes to SwiftData + “Saved!” alert
    •    Practice totals with segmented view: Today / Week / Month / All
    •    Goal section:
    •    Segmented scope: Today / Week / Month
    •    Progress bar and X / goal minutes
    •    Streak appears only for Today goal scope

History
    •    SwiftData-backed session list.
    •    Header totals (Today, This Week).
    •    Searchable notes text (case-insensitive).
    •    Scope filter: All / Today / Week / Month.
    •    Tap row opens note editor sheet (SessionNoteView(sessionID:)).
    •    Swipe-to-delete + EditButton multi-delete.
    •    Export/Backup:
    •    Export CSV or JSON via share sheet
    •    Exports the currently visible (filtered/searched) sessions
    •    CSV escapes commas/quotes/newlines properly

Note Editor (SessionNoteView)
    •    Full-screen sheet with close (X).
    •    TextEditor for notes, theming-aware.
    •    Save updates SwiftData.
    •    Character soft limit:
    •    Soft limit = 5000 chars
    •    Over limit turns red + Save disabled

Friends (Game Center Foundation)
    •    Game Center authentication
    •    Add friends via Game Center friends UI
    •    Leaderboards:
    •    Weekly / Monthly segmented control
    •    “Top 5” in-app preview
    •    Can open leaderboards via GKAccessPoint
    •    Submits weekly/monthly minutes totals (with submit caching)

Settings
    •    Help link -> HelpView
    •    Goals:
    •    Goal scope segmented (Today/Week/Month)
    •    Goal minutes Stepper (0 = Off)
    •    Appearance:
    •    System theme segmented: System / Light / Dark (stored in pb.settings.theme)
    •    Themes -> ThemePickerView
    •    Fonts -> FontPickerView
    •    History retention:
    •    Unlimited or fixed count (30/90/180/365/1000)
    •    Changing retention prunes immediately

Help
    •    In-app instructions for timer controls, saving/discarding, goals/streaks, history editing.

One-time Onboarding
    •    First launch onboarding sheet with swipe pages.
    •    Persisted flag prevents re-showing (pb.onboarding.didShow).

⸻

Day 5 Major Changes / Improvements

1) Typography System (Theme + Font Pack aware)
    •    PBTypography now supports:
    •    Theme-aware style mapping (Classic / Mint / Concert Hall / fallback)
    •    Font pack injection via PBFontChoice
    •    Additional roles used across UI:
    •    cardTitle
    •    sheetTitle
    •    sectionTitle
    •    button
    •    timer
    •    number
    •    heroTracking
    •    Typography is injected app-wide via environment:
    •    EnvironmentValues.pbTypography
    •    .pbTypography(...) at root in ContentView

2) Font Packs are “full app makeover”
    •    Fonts are now conceptual “packs” (a palette of roles):
    •    titleKind / headlineKind / bodyKind / numberKind
    •    Global font “nudge” is applied at app root using:
    •    .fontDesign(fontChoice.globalBodyDesign) (or helper .pbGlobalFontDesign(fontChoice))

3) Removed purchases/unlocking from themes & fonts
    •    Themes and fonts are now free (no more Theme Pack / Font Pack unlock logic).
    •    Store concept is still desired but will be for future unlockable features only (currently placeholder/coming soon direction).

4) Fixed “scroll jumps to top” when changing Light/Dark/System
    •    Previously, TabView was forced to rebuild on colorScheme changes via .id(colorScheme) to repaint tab bar.
    •    That caused Settings page scroll position to reset when switching appearance.
    •    Day 5 fix:
    •    Removed .id(colorScheme)
    •    Added UIKit-driven tab bar appearance refresh without rebuilding SwiftUI tree.

5) Simplified Fonts UI
    •    Removed redundant “Open Store” / “Store (Features)” link from Fonts screen.

⸻

Persistence Status
    •    Sessions: Persisted using SwiftData (survives relaunch/device restart)
    •    Settings + timer state: persisted via @AppStorage
    •    Confirmed persistence works on Simulator and real device

⸻

App Storage Keys

Timer
    •    pb.practice.accumulatedSeconds (Int)
    •    pb.practice.startEpoch (Double)
    •    pb.practice.isRunning (Bool)

Settings
    •    pb.settings.historyRetention (Int; 0 = unlimited)
    •    pb.settings.theme (String; Light/Dark/System raw value)
    •    pb.settings.dailyGoalMinutes (Int)
    •    pb.settings.goalScope (String; GoalScope raw value)

Home display preferences
    •    pb.home.practiceTimeMode (String; PracticeTimeDisplayMode raw value)

Themes
    •    pb.settings.colorThemeID (String; PBTheme id)

Fonts
    •    pb.settings.fontID (String; PBFontChoice id)  (PBFontChoice.selectionKey)

Onboarding
    •    pb.onboarding.didShow (Bool)

Tab selection
    •    pb.tab.selection (Int)

⸻

Data Model (SwiftData)

PracticeSessionModel (@Model)
    •    id: UUID
    •    date: Date
    •    durationSeconds: Int
    •    notes: String

(Old PracticeSession struct may still exist but app uses SwiftData model.)

⸻

Project Structure (Groups)
    •    App/
    •    PracticeBuddyApp.swift
    •    ContentView.swift (updated Day 5: removed TabView rebuild; added PBTabBarStyle; typography/font pack injection)
    •    Features/
    •    Home/
    •    HomeView.swift
    •    History/
    •    HistoryView.swift
    •    SessionNoteView.swift
    •    Friends/
    •    FriendsView.swift
    •    SocialShareCardView.swift
    •    GameCenterManager.swift
    •    Settings/
    •    SettingsView.swift
    •    ThemePickerView.swift
    •    FontPickerView.swift (updated Day 5: removed Store link)
    •    Help/
    •    HelpView.swift
    •    Onboarding/
    •    OnboardingView.swift
    •    Models/
    •    PracticeSessionModel.swift
    •    Services/
    •    SessionStore.swift
    •    ThemeManager.swift
    •    SharedUI/
    •    DurationFormatter.swift
    •    AppTheme.swift
    •    Scopes.swift (PracticeTimeDisplayMode, GoalScope)
    •    PBTheme.swift
    •    ThemeEnvironment.swift
    •    PBTypography.swift (updated Day 5)
    •    PBTypographyEnvironment.swift (updated Day 5)
    •    PBFontChoice.swift
    •    PBTabBarStyle.swift (NEW Day 5)
    •    ActivityView.swift
    •    Docs/
    •    PROJECT_SNAPSHOT.md
    •    Assets/

⸻

Known Limitations / TODO
    •    Store should exist as Feature Unlocks only (placeholder for now, “Coming soon”).
    •    Game Center leaderboards may show “application not recognized” until App Store Connect Game Center setup + TestFlight build exists.
    •    Consider a future “Typography adoption pass” to ensure every screen uses @Environment(\.pbTypography) consistently (History may still use more default fonts in some places depending on what was updated earlier).
    •    iCloud sync not implemented (future).
    •    Metronome not implemented (future).

⸻

Where We Stopped (End of Day 5)
    •    App builds with no errors.
    •    Switching Light/Dark/System no longer resets Settings scroll position.
    •    Themes and Font packs are free and selectable.
    •    Typography environment is stable (PBTypography + PBTypographyEnvironment).
    •    Fonts screen no longer shows redundant Store link.
    •    Next session planned: brainstorming ideas rather than coding.
