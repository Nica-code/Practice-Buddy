import SwiftUI
import SwiftData

@main
struct PracticeBuddyApp: App {

    // Your project already stores a theme raw string in AppStorage.
    // We won't assume exact enum cases; we'll map strings safely.
    @AppStorage("pb.settings.theme") private var themeRaw: String = "system"

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(mappedColorScheme(from: themeRaw))
        }
        .modelContainer(for: PracticeSessionModel.self)
    }

    private func mappedColorScheme(from raw: String) -> ColorScheme? {
        let v = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()

        // Accept common values: "auto", "system", "systemdefault", etc.
        if v.contains("auto") || v.contains("system") {
            return nil
        }
        if v.contains("light") {
            return .light
        }
        if v.contains("dark") {
            return .dark
        }
        return nil
    }
}
