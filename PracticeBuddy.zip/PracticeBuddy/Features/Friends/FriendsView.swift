import SwiftUI
import SwiftData

struct FriendsView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type

    @StateObject private var social = LocalSocialProvider()
    @StateObject private var gameCenter = GameCenterManager()

    @State private var selectedSharePeriod: SocialPeriod = .week
    @State private var leaderboardFriendsOnly: Bool = true

    private enum LeaderboardPeriod: String, CaseIterable, Identifiable {
        case weekly
        case monthly

        var id: String { rawValue }

        var title: String {
            switch self {
            case .weekly: return "Weekly"
            case .monthly: return "Monthly"
            }
        }

        var leaderboardID: String {
            switch self {
            case .weekly: return GameCenterManager.PracticeLeaderboards.weeklyMinutesID
            case .monthly: return GameCenterManager.PracticeLeaderboards.monthlyMinutesID
            }
        }
    }

    @State private var selectedLeaderboardPeriod: LeaderboardPeriod = .weekly

    // ✅ prevent repeated configure + repeated refresh storms
    @State private var didConfigure = false

    // ✅ throttle Game Center submissions
    @State private var lastSubmittedWeekMinutes: Int = -1
    @State private var lastSubmittedMonthMinutes: Int = -1

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                headerCard
                gameCenterCard
                leaderboardsCard
                totalsCard
                shareCard
                comingSoonCard
            }
            .padding(.horizontal)
            .padding(.top, 12)
            .padding(.bottom, PBLayout.padXL)
        }
        .background(theme.background.ignoresSafeArea())
        .task {
            guard !didConfigure else { return }
            didConfigure = true

            social.configure(modelContext: modelContext)
            gameCenter.configure()
        }
        .onReceive(social.$totals) { totals in
            let weekMinutes = max(0, totals.weekSeconds / 60)
            let monthMinutes = max(0, totals.monthSeconds / 60)

            guard weekMinutes != lastSubmittedWeekMinutes || monthMinutes != lastSubmittedMonthMinutes else { return }
            lastSubmittedWeekMinutes = weekMinutes
            lastSubmittedMonthMinutes = monthMinutes

            gameCenter.submitPracticeTotals(weekMinutes: weekMinutes, monthMinutes: monthMinutes)
        }
        .task(id: leaderboardTaskKey) {
            await refreshLeaderboardPreview()
        }
        .sheet(item: $gameCenter.authSheet) { (sheet: GameCenterManager.AuthSheet) in
            UIKitViewControllerContainer(viewController: sheet.viewController)
        }
    }

    // MARK: - Task key

    private var leaderboardTaskKey: String {
        "\(selectedLeaderboardPeriod.rawValue)-\(leaderboardFriendsOnly)-\(gameCenter.isAuthenticated)"
    }

    // MARK: - Actions

    private func refreshLeaderboardPreview() async {
        guard gameCenter.isAuthenticated else { return }
        await gameCenter.loadLeaderboardPreview(
            leaderboardID: selectedLeaderboardPeriod.leaderboardID,
            friendsOnly: leaderboardFriendsOnly,
            limit: 5
        )
    }

    private func manualRefresh() {
        Task { await refreshLeaderboardPreview() }
    }

    // MARK: - Cards

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Your Studio")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Text("Now with Game Center: add friends, submit totals, and view leaderboards.")
                .font(type.body)
                .foregroundStyle(theme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var gameCenterCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Game Center")
                    .font(type.sectionTitle)
                    .foregroundStyle(theme.textPrimary)

                Spacer()

                Text(gameCenter.isAuthenticated ? "Signed In" : "Not Signed In")
                    .font(type.footnote)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(theme.surfaceAlt)
                    .clipShape(Capsule())
                    .foregroundStyle(theme.textSecondary)
            }

            if gameCenter.isAuthenticated, let name = gameCenter.displayName {
                Text("Signed in as \(name).")
                    .font(type.body)
                    .foregroundStyle(theme.textSecondary)
            } else if gameCenter.isAuthenticated {
                Text("Signed in.")
                    .font(type.body)
                    .foregroundStyle(theme.textSecondary)
            } else {
                Button {
                    gameCenter.authenticate()
                } label: {
                    Label("Sign in to Game Center", systemImage: "person.crop.circle.badge.checkmark")
                        .font(type.body)
                }
                .buttonStyle(.borderedProminent)

                Text("Sign in to submit totals and view leaderboards.")
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var leaderboardsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Leaderboards")
                    .font(type.sectionTitle)
                    .foregroundStyle(theme.textPrimary)

                Spacer()

                Button {
                    manualRefresh()
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .foregroundStyle(theme.textSecondary)
                }
                .buttonStyle(.plain)
            }

            Picker("Period", selection: $selectedLeaderboardPeriod) {
                ForEach(LeaderboardPeriod.allCases) { p in
                    Text(p.title).tag(p)
                }
            }
            .pickerStyle(.segmented)

            Toggle(isOn: $leaderboardFriendsOnly) {
                Text("Friends only")
                    .font(type.body)
            }

            if !gameCenter.isAuthenticated {
                Text("Sign in to see leaderboards.")
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(theme.surfaceAlt)
                    .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusControl, style: .continuous))
            } else if gameCenter.previewIsLoading {
                HStack(spacing: 10) {
                    ProgressView()
                    Text("Loading…")
                        .font(type.footnote)
                        .foregroundStyle(theme.textSecondary)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(theme.surfaceAlt)
                .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusControl, style: .continuous))
            } else if gameCenter.previewRows.isEmpty {
                Text("No scores yet.")
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(theme.surfaceAlt)
                    .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusControl, style: .continuous))
            } else {
                VStack(spacing: 8) {
                    // ✅ Explicit ID removes the Binding<C> inference issue
                    ForEach(gameCenter.previewRows, id: \.id) { row in
                        HStack(spacing: 10) {
                            Text("#\(row.rank)")
                                .font(type.footnote)
                                .foregroundStyle(theme.textSecondary)
                                .frame(width: 42, alignment: .leading)
                                .monospacedDigit()

                            Text(row.name)
                                .font(type.body)
                                .foregroundStyle(theme.textPrimary)
                                .lineLimit(1)

                            Spacer()

                            Text("\(row.minutes) min")
                                .font(type.number)
                                .foregroundStyle(theme.accent)
                                .monospacedDigit()
                        }
                        .padding(.vertical, 4)
                    }
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(theme.surfaceAlt)
                .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusControl, style: .continuous))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var totalsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Your Totals")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            VStack(spacing: 10) {
                totalsRow("Today", seconds: social.totals.todaySeconds)
                totalsRow("This week", seconds: social.totals.weekSeconds)
                totalsRow("This month", seconds: social.totals.monthSeconds)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private func totalsRow(_ title: String, seconds: Int) -> some View {
        HStack {
            Text(title)
                .font(type.body)
                .foregroundStyle(theme.textPrimary)
            Spacer()
            Text(DurationFormatter.string(from: seconds))
                .font(type.number)
                .foregroundStyle(theme.textSecondary)
                .monospacedDigit()
        }
    }

    private var shareCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Share")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Picker("Share Period", selection: $selectedSharePeriod) {
                ForEach(SocialPeriod.allCases) { p in
                    Text(p.title).tag(p)
                }
            }
            .pickerStyle(.segmented)

            ShareLink(
                item: social.shareText(for: selectedSharePeriod)
            ) {
                Label("Share text", systemImage: "square.and.arrow.up")
                    .font(type.body)
            }
            .buttonStyle(.borderedProminent)

            if let url = social.shareImageURL(for: selectedSharePeriod) {
                ShareLink(item: url) {
                    Label("Share image", systemImage: "photo")
                        .font(type.body)
                }
                .buttonStyle(.bordered)
            } else {
                Text("Image share requires iOS 16+.")
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var comingSoonCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Coming soon")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Text("Invites, friend requests, and group challenges.")
                .font(type.body)
                .foregroundStyle(theme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }
}
