import SwiftUI

struct FontPickerView: View {
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type

    @AppStorage(PBFontChoice.selectionKey) private var selectedFontID: String = PBFontChoice.systemDefault.id

    private var selected: PBFontChoice { PBFontChoice.byID(selectedFontID) }

    var body: some View {
        List {
            Section {
                previewCard
                    .listRowBackground(theme.background)
            }

            Section("Fonts") {
                ForEach(PBFontChoice.all) { choice in
                    fontRow(choice)
                        .listRowBackground(theme.surface)
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("Fonts")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var previewCard: some View {
        let previewChoice = selected
        let previewTitle = previewChoice.homeTitleFont(size: 28)

        return VStack(alignment: .leading, spacing: 10) {
            Text("Preview")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Text("Practice Buddy")
                .font(previewTitle)
                .foregroundStyle(theme.textPrimary)

            Text("This font pack applies across the app (where typography is used).")
                .font(type.body)
                .foregroundStyle(theme.textSecondary)

            HStack {
                Text("Today")
                    .font(previewChoice.bodyFont())
                    .foregroundStyle(theme.textPrimary)

                Spacer()

                Text("42 min")
                    .font(previewChoice.numberFont(size: 16, weight: .semibold))
                    .foregroundStyle(theme.accent)
                    .monospacedDigit()
            }
            .padding(12)
            .background(theme.surfaceAlt)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .padding()
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func fontRow(_ choice: PBFontChoice) -> some View {
        let isSelected = (choice.id == selectedFontID)

        return Button {
            selectedFontID = choice.id
        } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 8) {
                        Text(choice.name)
                            .font(type.body.weight(.semibold))
                            .foregroundStyle(theme.textPrimary)

                        if isSelected {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(theme.accent)
                        }
                    }

                    Text("Tap to apply")
                        .font(type.footnote)
                        .foregroundStyle(theme.textSecondary)
                        .opacity(0.85)
                }

                Spacer()

                Text("Aa")
                    .font(choice.homeTitleFont(size: 20))
                    .foregroundStyle(theme.textPrimary)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(theme.surfaceAlt)
                    .clipShape(Capsule())
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
