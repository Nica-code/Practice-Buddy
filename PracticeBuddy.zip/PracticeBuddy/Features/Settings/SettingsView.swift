import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: SessionStore
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type
    @Environment(\.colorScheme) private var colorScheme

    @AppStorage("pb.settings.historyRetention") private var historyRetention: Int = 0
    @AppStorage("pb.settings.theme") private var themeRawValue: String = AppTheme.system.rawValue

    @AppStorage("pb.settings.dailyGoalMinutes") private var goalMinutes: Int = 30
    @AppStorage("pb.settings.goalScope") private var goalScopeRaw: String = GoalScope.today.rawValue

    @State private var pendingRetentionWorkItem: DispatchWorkItem?

    private var goalScopeBinding: Binding<GoalScope> {
        Binding(
            get: { GoalScope(rawValue: goalScopeRaw) ?? .today },
            set: { goalScopeRaw = $0.rawValue }
        )
    }

    private var chrome: Color { theme.chromeBackground(for: colorScheme) }

    var body: some View {
        Form {
            Section("Goals") {
                Picker("Goal period", selection: goalScopeBinding) {
                    ForEach(GoalScope.allCases) { scope in
                        Text(scope.title).tag(scope)
                    }
                }
                .pickerStyle(.segmented)

                Stepper(value: $goalMinutes, in: 0...600, step: 5) {
                    HStack {
                        Text("Goal")
                            .font(type.body)
                        Spacer()
                        Text(goalMinutes == 0
                             ? "Off"
                             : "\(goalMinutes) min / \((GoalScope(rawValue: goalScopeRaw) ?? .today).title.lowercased())")
                        .font(type.body)
                        .foregroundStyle(theme.textSecondary)
                        .monospacedDigit()
                    }
                }

                Text(goalMinutes == 0 ? "Turn this on to track progress." : "Progress is tracked for the selected period.")
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
            }
            .listRowBackground(theme.surface)

            Section("Appearance") {
                Picker(
                    "Theme",
                    selection: Binding<AppTheme>(
                        get: { AppTheme(rawValue: themeRawValue) ?? .system },
                        set: { themeRawValue = $0.rawValue }
                    )
                ) {
                    ForEach(AppTheme.allCases) { t in
                        Text(t.displayName).tag(t)
                    }
                }
                .pickerStyle(.segmented)

                NavigationLink { PBLazyView(ThemePickerView()) } label: {
                    Label("Themes", systemImage: "paintpalette")
                        .font(type.body)
                }

                NavigationLink { PBLazyView(FontPickerView()) } label: {
                    Label("Fonts", systemImage: "textformat")
                        .font(type.body)
                }

                NavigationLink { PBLazyView(AppIconPickerView()) } label: {
                    Label("App Icon", systemImage: "app.badge")
                        .font(type.body)
                }
            }
            .listRowBackground(theme.surface)

            Section("History") {
                Picker("Keep history", selection: $historyRetention) {
                    Text("Unlimited").tag(0)
                    Text("30").tag(30)
                    Text("90").tag(90)
                    Text("180").tag(180)
                    Text("365").tag(365)
                    Text("1000").tag(1000)
                }

                Text(historyRetention == 0
                     ? "Your practice history is kept indefinitely."
                     : "Older sessions are automatically deleted after you exceed \(historyRetention) sessions.")
                .font(type.footnote)
                .foregroundStyle(theme.textSecondary)
            }
            .listRowBackground(theme.surface)
        }
        .scrollContentBackground(.hidden)
        .background(chrome.ignoresSafeArea())
        .toolbarBackground(chrome, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .navigationTitle("Settings")
        .onChange(of: historyRetention) { _, _ in
            // Debounced retention prune (prevents update loops)
            pendingRetentionWorkItem?.cancel()

            let item = DispatchWorkItem {
                store.retentionChanged()
            }

            pendingRetentionWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: item)
        }
    }
}
