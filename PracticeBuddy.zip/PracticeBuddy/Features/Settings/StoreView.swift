import SwiftUI

struct StoreView: View {
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                headerCard
                comingSoonCard
                examplesCard
            }
            .padding(.horizontal)
            .padding(.top, 12)
            .padding(.bottom, PBLayout.padXL)
        }
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("Store")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Unlockable Features")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Text("Themes and fonts are free. The Store will be for future feature unlocks.")
                .font(type.body)
                .foregroundStyle(theme.textSecondary)
        }
        .padding(PBLayout.padMD)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var comingSoonCard: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(theme.accent.opacity(0.18))
                    .frame(width: 44, height: 44)
                Image(systemName: "sparkles")
                    .foregroundStyle(theme.accent)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Coming soon")
                    .font(type.sectionTitle)
                    .foregroundStyle(theme.textPrimary)

                Text("We’re preparing new upgrades you can unlock forever.")
                    .font(type.body)
                    .foregroundStyle(theme.textSecondary)
            }

            Spacer()
        }
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private var examplesCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Examples (not available yet)")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            featureRow(icon: "metronome", title: "Metronome", subtitle: "Tap tempo, accents, background audio")
            featureRow(icon: "chart.line.uptrend.xyaxis", title: "Insights", subtitle: "Trends, weekly summaries, best streaks")
            featureRow(icon: "bell.badge", title: "Reminders", subtitle: "Practice nudges and streak protection")

            Text("Everything here is just a placeholder for now.")
                .font(type.footnote)
                .foregroundStyle(theme.textSecondary)
        }
        .padding(PBLayout.padMD)
        .background(theme.surface)
        .clipShape(RoundedRectangle(cornerRadius: PBLayout.radiusCard, style: .continuous))
    }

    private func featureRow(icon: String, title: String, subtitle: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(theme.textSecondary)
                .frame(width: 22)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(type.body.weight(.semibold))
                    .foregroundStyle(theme.textPrimary)
                Text(subtitle)
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
            }

            Spacer()

            Text("Soon")
                .font(type.footnote)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(theme.surfaceAlt)
                .clipShape(Capsule())
                .foregroundStyle(theme.textSecondary)
        }
    }
}
