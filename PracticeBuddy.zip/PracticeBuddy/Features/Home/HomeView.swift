import SwiftUI
import Combine

struct HomeView: View {
    @EnvironmentObject private var store: SessionStore
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type
    @Environment(\.colorScheme) private var colorScheme

    // Timer persisted state
    @AppStorage("pb.practice.accumulatedSeconds") private var accumulatedSeconds: Int = 0
    @AppStorage("pb.practice.startEpoch") private var startEpoch: Double = 0
    @AppStorage("pb.practice.isRunning") private var isRunning: Bool = false

    // Goal settings
    @AppStorage("pb.settings.dailyGoalMinutes") private var goalMinutes: Int = 30
    @AppStorage("pb.settings.goalScope") private var goalScopeRaw: String = GoalScope.today.rawValue

    // Home display settings
    @AppStorage("pb.home.practiceTimeMode") private var practiceTimeModeRaw: String = PracticeTimeDisplayMode.all.rawValue

    // Live tick for the timer row
    @State private var now = Date()
    @State private var timerCancellable: AnyCancellable? = nil

    private enum Constants {
        static let tickSeconds: TimeInterval = 1
        static let titleTopPadding: CGFloat = 18
        static let titleBottomPadding: CGFloat = 8
    }

    // Save flow
    @State private var showSaveSheet = false
    @State private var notes: String = ""
    @State private var showSavedAlert = false

    // Haptics
    private let impact = UIImpactFeedbackGenerator(style: .soft)
    private let notify = UINotificationFeedbackGenerator()

    // MARK: - Bindings

    private var practiceTimeMode: Binding<PracticeTimeDisplayMode> {
        Binding(
            get: { PracticeTimeDisplayMode(rawValue: practiceTimeModeRaw) ?? .all },
            set: { practiceTimeModeRaw = $0.rawValue }
        )
    }

    private var goalScope: Binding<GoalScope> {
        Binding(
            get: { GoalScope(rawValue: goalScopeRaw) ?? .today },
            set: { goalScopeRaw = $0.rawValue }
        )
    }

    // MARK: - Timer derived

    private var startDate: Date? {
        startEpoch > 0 ? Date(timeIntervalSince1970: startEpoch) : nil
    }

    private var currentElapsedSeconds: Int {
        if isRunning, let startDate {
            let running = Int(now.timeIntervalSince(startDate))
            return accumulatedSeconds + max(0, running)
        } else {
            return accumulatedSeconds
        }
    }

    private var hasAnyTime: Bool { currentElapsedSeconds > 0 }
    private var canStop: Bool { hasAnyTime || isRunning }

    private var primaryButtonTitle: String {
        if isRunning { return "Pause" }
        if hasAnyTime { return "Resume" }
        return "Start"
    }

    // MARK: - Goal derived

    private var goalSeconds: Int { max(0, goalMinutes) * 60 }

    private var scopedSeconds: Int {
        switch GoalScope(rawValue: goalScopeRaw) ?? .today {
        case .today: return store.totalTodaySeconds
        case .week: return store.totalThisWeekSeconds
        case .month: return store.totalThisMonthSeconds
        }
    }

    private var goalProgress: Double {
        guard goalSeconds > 0 else { return 0 }
        return min(1.0, Double(scopedSeconds) / Double(goalSeconds))
    }

    private var streakDays: Int {
        let scope = GoalScope(rawValue: goalScopeRaw) ?? .today
        guard scope == .today else { return 0 }
        return store.currentStreakDays(dailyGoalMinutes: goalMinutes)
    }

    private var chrome: Color { theme.chromeBackground(for: colorScheme) }

    var body: some View {
        VStack(spacing: 0) {
            Text("Practice Buddy")
                .font(type.appTitle)
                .tracking(type.heroTracking)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.top, Constants.titleTopPadding)
                .padding(.bottom, Constants.titleBottomPadding)
                .foregroundStyle(theme.textPrimary)

            List {
                Section {
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(isRunning ? "Practicing" : (hasAnyTime ? "Paused" : "Ready"))
                                .font(type.statusLabel)
                                .foregroundStyle(theme.textSecondary)

                            Text(DurationFormatter.string(from: currentElapsedSeconds))
                                .font(type.timer)
                                .monospacedDigit()
                                .foregroundStyle(theme.textPrimary)
                        }

                        Spacer()

                        Button(primaryButtonTitle) {
                            hapticSoftTap()
                            toggleStartPauseOrStart()
                        }
                        .font(type.button)
                        .buttonStyle(.borderedProminent)

                        Button("Stop") {
                            hapticSoftTap()
                            stopTapped()
                        }
                        .font(type.button)
                        .buttonStyle(.bordered)
                        .disabled(!canStop)
                    }
                    .padding(.vertical, 4)
                }
                .listRowBackground(theme.surface)

                Section("Practice Time") {
                    Picker("View", selection: practiceTimeMode) {
                        ForEach(PracticeTimeDisplayMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)

                    switch PracticeTimeDisplayMode(rawValue: practiceTimeModeRaw) ?? .all {
                    case .today:
                        row("Today", seconds: store.totalTodaySeconds)
                    case .week:
                        row("This week", seconds: store.totalThisWeekSeconds)
                    case .month:
                        row("This month", seconds: store.totalThisMonthSeconds)
                    case .all:
                        row("Today", seconds: store.totalTodaySeconds)
                        row("This week", seconds: store.totalThisWeekSeconds)
                        row("This month", seconds: store.totalThisMonthSeconds)
                    }
                }
                .listRowBackground(theme.surface)

                Section("Goal") {
                    Picker("Period", selection: goalScope) {
                        ForEach(GoalScope.allCases) { scope in
                            Text(scope.title).tag(scope)
                        }
                    }
                    .pickerStyle(.segmented)

                    if goalMinutes == 0 {
                        Text("Goal is off. Turn it on in Settings.")
                            .foregroundStyle(theme.textSecondary)
                    } else {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text((GoalScope(rawValue: goalScopeRaw) ?? .today) == .today ? "Today" :
                                     (GoalScope(rawValue: goalScopeRaw) ?? .today) == .week ? "This week" : "This month")
                                Spacer()
                                Text("\(DurationFormatter.string(from: scopedSeconds)) / \(goalMinutes) min")
                                    .font(type.number)
                                    .foregroundStyle(theme.textSecondary)
                                    .monospacedDigit()
                            }

                            ProgressView(value: goalProgress)

                            if (GoalScope(rawValue: goalScopeRaw) ?? .today) == .today {
                                HStack {
                                    Text("Streak")
                                    Spacer()
                                    Text("\(streakDays) day\(streakDays == 1 ? "" : "s")")
                                        .font(type.number)
                                        .monospacedDigit()
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listRowBackground(theme.surface)
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
        }
        .background(chrome.ignoresSafeArea())
        .toolbarBackground(chrome, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            impact.prepare()
            notify.prepare()

            // Only tick while visible AND running.
            if isRunning {
                startTicker()
            }
        }
        .onChange(of: isRunning) { _, running in
            if running {
                now = Date()
                startTicker()
            } else {
                stopTicker()
            }
        }
        .onDisappear {
            stopTicker()
        }
        .sheet(isPresented: $showSaveSheet) {
            saveSheet
        }
        .alert("Saved!", isPresented: $showSavedAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Your practice session was added to History.")
        }
    }

    // MARK: - Ticker control

    private func startTicker() {
        guard timerCancellable == nil else { return }
        timerCancellable = Timer.publish(every: Constants.tickSeconds, on: .main, in: .common)
            .autoconnect()
            .sink { _ in
                now = Date()
            }
    }

    private func stopTicker() {
        timerCancellable?.cancel()
        timerCancellable = nil
    }

    private func row(_ title: String, seconds: Int) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(DurationFormatter.string(from: seconds))
                .font(type.number)
                .monospacedDigit()
        }
    }

    private func toggleStartPauseOrStart() {
        if isRunning {
            accumulatedSeconds = currentElapsedSeconds
            isRunning = false
            startEpoch = 0
        } else {
            if !hasAnyTime {
                accumulatedSeconds = 0
            }
            startEpoch = Date().timeIntervalSince1970
            isRunning = true
        }
    }

    private func stopTapped() {
        if isRunning {
            accumulatedSeconds = currentElapsedSeconds
            isRunning = false
            startEpoch = 0
        }
        showSaveSheet = true
    }

    private func resetSession() {
        accumulatedSeconds = 0
        startEpoch = 0
        isRunning = false
        notes = ""
    }

    private var saveSheet: some View {
        NavigationStack {
            Form {
                Section("Session") {
                    Text("Duration: \(DurationFormatter.string(from: currentElapsedSeconds))")
                        .font(type.number)
                }
                Section("Notes (optional)") {
                    TextField("What did you practice?", text: $notes, axis: .vertical)
                        .font(type.body)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle("Save Session")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Discard") {
                        hapticSoftTap()
                        resetSession()
                        showSaveSheet = false
                    }
                    .font(type.button)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        hapticSuccess()
                        store.addSession(
                            date: Date(),
                            durationSeconds: currentElapsedSeconds,
                            notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
                        )
                        resetSession()
                        showSaveSheet = false
                        showSavedAlert = true
                    }
                    .font(type.button)
                    .disabled(currentElapsedSeconds == 0)
                }
            }
        }
    }

    private func hapticSoftTap() {
        impact.impactOccurred()
        impact.prepare()
    }

    private func hapticSuccess() {
        notify.notificationOccurred(.success)
        notify.prepare()
    }
}
