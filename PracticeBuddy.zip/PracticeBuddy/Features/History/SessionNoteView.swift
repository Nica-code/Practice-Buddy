import SwiftUI
import os

struct SessionNoteView: View {
    @EnvironmentObject private var store: SessionStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type

    let sessionID: UUID

    @State private var draftNotes: String = ""
    @State private var didLoad = false

    @State private var showSaved = false

    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "PracticeBuddy",
                                category: "session-note")

    var body: some View {
        NavigationStack {
            Form {
                Section("Notes") {
                    TextEditor(text: $draftNotes)
                        .font(type.body)
                        .frame(minHeight: 180)
                }
                .listRowBackground(theme.surface)

                Section {
                    Text("\(draftNotes.count) characters")
                        .font(type.footnote)
                        .foregroundStyle(theme.textSecondary)
                }
                .listRowBackground(theme.surface)
            }
            .scrollContentBackground(.hidden)
            .background(theme.background.ignoresSafeArea())
            .navigationTitle("Edit Notes")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        dismiss()
                    }
                    .font(type.button)
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveTapped()
                    }
                    .font(type.button)
                    .disabled(!canSave)
                }
            }
            .onAppear {
                if !didLoad {
                    didLoad = true
                    draftNotes = initialNotes()
                }
            }
            .alert("Saved", isPresented: $showSaved) {
                Button("OK", role: .cancel) {
                    dismiss()
                }
            } message: {
                Text("Your notes were updated.")
            }
        }
    }

    private var canSave: Bool {
        // Allow empty notes too, but prevent saving if it didn’t change anything.
        draftNotes != initialNotes()
    }

    private func initialNotes() -> String {
        store.sessions.first(where: { $0.id == sessionID })?.notes ?? ""
    }

    private func saveTapped() {
        let trimmed = draftNotes.trimmingCharacters(in: .whitespacesAndNewlines)
        store.updateNotes(for: sessionID, notes: trimmed)
        logger.debug("Saved notes for session \(self.sessionID.uuidString, privacy: .public)")
        showSaved = true
    }
}
