import SwiftUI
import os

struct HistoryView: View {

    // MARK: - Local Types (were missing)

    private enum HistoryScope: String, CaseIterable, Identifiable {
        case all
        case today
        case week
        case month

        var id: String { rawValue }

        var title: String {
            switch self {
            case .all: return "All"
            case .today: return "Today"
            case .week: return "Week"
            case .month: return "Month"
            }
        }
    }

    private struct SelectedID: Identifiable, Hashable {
        let id: UUID
    }

    private enum ExportFormat {
        case csv
        case json

        var serviceFormat: SessionExportService.ExportFormat {
            switch self {
            case .csv: return .csv
            case .json: return .json
            }
        }
    }

    private let logger = Logger(subsystem: "PracticeBuddy", category: "history")

    // MARK: - Environment

    @EnvironmentObject private var store: SessionStore
    @Environment(\.pbTheme) private var theme
    @Environment(\.pbTypography) private var type

    // MARK: - State

    @State private var searchText: String = ""
    @State private var scope: HistoryScope = .all

    // Export UI state
    @State private var showExportOptions: Bool = false
    @State private var exportURL: URL? = nil
    @State private var showShareSheet: Bool = false
    @State private var exportErrorMessage: String? = nil
    @State private var showExportError: Bool = false

    // Note editor
    @State private var selectedSheetID: SelectedID? = nil

    // MARK: - Body

    var body: some View {
        List {
            scopePickerSection

            if filteredSessions.isEmpty {
                emptyStateRow
                    .listRowBackground(theme.surface)
            } else {
                Section {
                    ForEach(filteredSessions) { session in
                        sessionRow(session)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedSheetID = SelectedID(id: session.id)
                            }
                            .listRowBackground(theme.surface)
                    }
                    .onDelete { offsets in
                        delete(offsets: offsets, from: filteredSessions)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("History")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showExportOptions = true } label: {
                    Image(systemName: "square.and.arrow.up")
                }
                .accessibilityLabel("Export")
            }

            ToolbarItem(placement: .topBarTrailing) {
                EditButton()
            }
        }
        .searchable(
            text: $searchText,
            placement: .navigationBarDrawer(displayMode: .always),
            prompt: "Search notes"
        )
        .confirmationDialog("Export", isPresented: $showExportOptions, titleVisibility: .visible) {
            Button("Export CSV") { export(format: .csv) }
            Button("Export JSON") { export(format: .json) }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Exports the currently shown (filtered) sessions.")
        }
        .alert("Export Failed", isPresented: $showExportError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(exportErrorMessage ?? "Unknown error.")
        }
        .sheet(isPresented: $showShareSheet) {
            if let exportURL {
                ActivityView(activityItems: [exportURL])
                    .presentationDetents([.medium, .large])
            } else {
                Text("Nothing to share.")
                    .padding()
            }
        }
        .sheet(item: $selectedSheetID) { (wrapper: SelectedID) in
            SessionNoteView(sessionID: wrapper.id)
        }
    }

    // MARK: - Sections

    private var scopePickerSection: some View {
        Section {
            Picker("Scope", selection: $scope) {
                ForEach(HistoryScope.allCases) { s in
                    Text(s.title).tag(s)
                }
            }
            .pickerStyle(.segmented)

            HStack {
                Text("Sessions")
                    .font(type.body)
                Spacer()
                Text("\(filteredSessions.count)")
                    .font(type.number)
                    .foregroundStyle(theme.textSecondary)
                    .monospacedDigit()
            }
        }
        .listRowBackground(theme.surface)
    }

    private var emptyStateRow: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("No sessions yet")
                .font(type.sectionTitle)
                .foregroundStyle(theme.textPrimary)

            Text("Start a timer on Home and save your first session.")
                .font(type.body)
                .foregroundStyle(theme.textSecondary)
        }
        .padding(.vertical, 10)
    }

    private func sessionRow(_ session: PracticeSessionModel) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(session.date.formatted(date: .abbreviated, time: .shortened))
                    .font(type.body)
                    .foregroundStyle(theme.textPrimary)

                Spacer()

                Text(DurationFormatter.string(from: session.durationSeconds))
                    .font(type.number)
                    .foregroundStyle(theme.textSecondary)
                    .monospacedDigit()
            }

            let trimmed = session.notes.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmed.isEmpty {
                Text(trimmed)
                    .font(type.footnote)
                    .foregroundStyle(theme.textSecondary)
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 6)
    }

    // MARK: - Filtering

    private var filteredSessions: [PracticeSessionModel] {
        var base = sessionsFilteredByScope(scope)

        let needle = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !needle.isEmpty else { return base }

        let lowered = needle.lowercased()
        base = base.filter { $0.notes.lowercased().contains(lowered) }
        return base
    }

    private func sessionsFilteredByScope(_ scope: HistoryScope) -> [PracticeSessionModel] {
        let cal = Calendar.current
        let now = Date()

        switch scope {
        case .all:
            return store.sessions

        case .today:
            guard let interval = cal.dateInterval(of: .day, for: now) else { return [] }
            return store.sessions.filter { $0.date >= interval.start && $0.date < interval.end }

        case .week:
            guard let interval = cal.dateInterval(of: .weekOfYear, for: now) else { return [] }
            return store.sessions.filter { $0.date >= interval.start && $0.date < interval.end }

        case .month:
            guard let interval = cal.dateInterval(of: .month, for: now) else { return [] }
            return store.sessions.filter { $0.date >= interval.start && $0.date < interval.end }
        }
    }

    // MARK: - Delete

    private func delete(offsets: IndexSet, from filtered: [PracticeSessionModel]) {
        let ids = offsets.map { filtered[$0].id }
        store.deleteSessions(withIDs: ids)
    }

    // MARK: - Export

    private func export(format: ExportFormat) {
        do {
            let url = try SessionExportService.export(
                sessions: filteredSessions,
                format: format.serviceFormat
            )
            exportURL = url
            showShareSheet = true
        } catch {
            logger.error("Export failed: \(String(describing: error), privacy: .public)")
            exportErrorMessage = error.localizedDescription
            showExportError = true
        }
    }
}
