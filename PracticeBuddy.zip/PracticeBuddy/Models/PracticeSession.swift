//
//  PracticeSession.swift
//  PracticeBuddy
//
//  Created by Nica on 1/26/26.
//
import Foundation

struct PracticeSession: Identifiable, Codable, Equatable {
    let id: UUID
    let date: Date
    let durationSeconds: Int
    let notes: String

    init(id: UUID = UUID(), date: Date = Date(), durationSeconds: Int, notes: String) {
        self.id = id
        self.date = date
        self.durationSeconds = durationSeconds
        self.notes = notes
    }
}
