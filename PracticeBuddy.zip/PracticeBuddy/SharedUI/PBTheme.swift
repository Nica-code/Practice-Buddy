import SwiftUI

struct PBTheme: Identifiable {
    enum Access: Equatable {
        case free
        case paid(productID: String) // kept for future; currently unused
    }

    struct Palette: Equatable {
        let background: Color
        let surface: Color
        let surfaceAlt: Color
        let textPrimary: Color
        let textSecondary: Color
        let accent: Color
    }

    let id: String
    let name: String
    let access: Access

    let palette: Palette
    let dynamicPalette: ((ColorScheme) -> Palette)?

    func resolvedPalette(for colorScheme: ColorScheme) -> Palette {
        dynamicPalette?(colorScheme) ?? palette
    }

    func chromeBackground(for colorScheme: ColorScheme) -> Color {
        if id == PBTheme.classic.id, colorScheme == .dark {
            return .black
        }
        return resolvedPalette(for: colorScheme).background
    }

    var background: Color { palette.background }
    var surface: Color { palette.surface }
    var surfaceAlt: Color { palette.surfaceAlt }
    var textPrimary: Color { palette.textPrimary }
    var textSecondary: Color { palette.textSecondary }
    var accent: Color { palette.accent }
}

extension PBTheme {
    static let themePackProductID = "pb_theme_pack" // kept for future, currently unused

    // MARK: - Classic (DO NOT CHANGE)
    static let classic = PBTheme(
        id: "classic",
        name: "Classic",
        access: .free,
        palette: .init(
            background: Color(uiColor: .systemGroupedBackground),
            surface: Color(uiColor: .secondarySystemGroupedBackground),
            surfaceAlt: Color(uiColor: .tertiarySystemGroupedBackground),
            textPrimary: .primary,
            textSecondary: .secondary,
            accent: .blue
        ),
        dynamicPalette: nil
    )

    // MARK: - Mint (formerly "Midnight") — ADAPTIVE
    // IMPORTANT: Keep id = "midnight" so existing saved selections still work.
    static let midnight = PBTheme(
        id: "midnight",
        name: "Mint",
        access: .free,
        palette: .init(
            background: .black,
            surface: Color(uiColor: .systemGray6).opacity(0.16),
            surfaceAlt: Color(uiColor: .systemGray6).opacity(0.10),
            textPrimary: .white,
            textSecondary: Color.white.opacity(0.75),
            accent: Color(red: 0.12, green: 0.62, blue: 0.36)
        ),
        dynamicPalette: { scheme in
            let mint = Color(red: 0.12, green: 0.62, blue: 0.36)

            if scheme == .dark {
                return .init(
                    background: .black,
                    surface: Color(red: 0.10, green: 0.14, blue: 0.12).opacity(0.98),
                    surfaceAlt: Color(red: 0.08, green: 0.11, blue: 0.10).opacity(0.98),
                    textPrimary: .white,
                    textSecondary: Color.white.opacity(0.78),
                    accent: mint
                )
            } else {
                return .init(
                    background: Color(red: 0.92, green: 0.96, blue: 0.94),
                    surface: Color(red: 0.985, green: 0.995, blue: 0.990),
                    surfaceAlt: Color(red: 0.90, green: 0.96, blue: 0.92),
                    textPrimary: Color(red: 0.07, green: 0.10, blue: 0.12),
                    textSecondary: Color(red: 0.18, green: 0.25, blue: 0.22).opacity(0.88),
                    accent: mint
                )
            }
        }
    )

    // MARK: - Concert Hall — ADAPTIVE (NOW FREE)
    static let concertHall = PBTheme(
        id: "concert_hall",
        name: "Concert Hall",
        access: .free,
        palette: .init(
            background: .black,
            surface: Color(red: 0.12, green: 0.12, blue: 0.13),
            surfaceAlt: Color(red: 0.17, green: 0.17, blue: 0.19),
            textPrimary: .white,
            textSecondary: Color.white.opacity(0.75),
            accent: Color(red: 0.86, green: 0.70, blue: 0.20)
        ),
        dynamicPalette: { scheme in
            let brass = Color(red: 0.86, green: 0.70, blue: 0.20)

            if scheme == .dark {
                return .init(
                    background: Color(red: 0.04, green: 0.04, blue: 0.05),
                    surface: Color(red: 0.12, green: 0.10, blue: 0.12).opacity(0.98),
                    surfaceAlt: Color(red: 0.18, green: 0.15, blue: 0.18).opacity(0.98),
                    textPrimary: Color(red: 0.98, green: 0.97, blue: 0.95),
                    textSecondary: Color(red: 0.86, green: 0.83, blue: 0.78).opacity(0.85),
                    accent: brass
                )
            } else {
                return .init(
                    background: Color(red: 0.97, green: 0.95, blue: 0.92),
                    surface: Color(red: 0.995, green: 0.990, blue: 0.975),
                    surfaceAlt: Color(red: 0.93, green: 0.90, blue: 0.85),
                    textPrimary: Color(red: 0.14, green: 0.11, blue: 0.10),
                    textSecondary: Color(red: 0.33, green: 0.26, blue: 0.22).opacity(0.90),
                    accent: brass
                )
            }
        }
    )

    // MARK: - Luthier (formerly Warm Maple) — ADAPTIVE (NOW FREE)
    // IMPORTANT: Keep id = "warm_maple" so existing saved selections still work.
    static let warmMaple = PBTheme(
        id: "warm_maple",
        name: "Luthier",
        access: .free,
        palette: .init(
            background: Color(red: 0.98, green: 0.96, blue: 0.93),
            surface: Color(red: 0.94, green: 0.89, blue: 0.82),
            surfaceAlt: Color(red: 0.90, green: 0.84, blue: 0.76),
            textPrimary: Color(red: 0.18, green: 0.14, blue: 0.10),
            textSecondary: Color(red: 0.32, green: 0.25, blue: 0.19),
            accent: Color(red: 0.73, green: 0.33, blue: 0.20)
        ),
        dynamicPalette: { scheme in
            let maple = Color(red: 0.73, green: 0.33, blue: 0.20)

            if scheme == .dark {
                return .init(
                    background: Color(red: 0.07, green: 0.06, blue: 0.05),
                    surface: Color(red: 0.16, green: 0.12, blue: 0.09).opacity(0.98),
                    surfaceAlt: Color(red: 0.22, green: 0.16, blue: 0.12).opacity(0.98),
                    textPrimary: Color(red: 0.98, green: 0.96, blue: 0.94),
                    textSecondary: Color(red: 0.90, green: 0.84, blue: 0.78).opacity(0.85),
                    accent: maple
                )
            } else {
                return .init(
                    background: Color(red: 0.98, green: 0.96, blue: 0.93),
                    surface: Color(red: 0.995, green: 0.985, blue: 0.970),
                    surfaceAlt: Color(red: 0.93, green: 0.88, blue: 0.80),
                    textPrimary: Color(red: 0.18, green: 0.14, blue: 0.10),
                    textSecondary: Color(red: 0.32, green: 0.25, blue: 0.19).opacity(0.92),
                    accent: maple
                )
            }
        }
    )

    static let all: [PBTheme] = [classic, midnight, concertHall, warmMaple]

    static func byID(_ id: String) -> PBTheme {
        all.first(where: { $0.id == id }) ?? classic
    }
}
