import SwiftUI
import UIKit

enum PBTabBarStyle {
    /// Forces UITabBar to refresh its appearance without rebuilding SwiftUI views.
    @MainActor
    static func apply(colorScheme: ColorScheme) {
        let appearance = UITabBarAppearance()
        appearance.configureWithDefaultBackground()

        // Keep it clean and system-consistent.
        // iOS automatically picks appropriate materials, but we make sure it refreshes.
        appearance.backgroundEffect = UIBlurEffect(style: colorScheme == .dark ? .systemChromeMaterialDark : .systemChromeMaterialLight)

        // Optional: slightly higher contrast in dark mode
        appearance.shadowColor = UIColor.separator.withAlphaComponent(colorScheme == .dark ? 0.25 : 0.15)

        let tabBar = UITabBar.appearance()
        tabBar.standardAppearance = appearance
        tabBar.scrollEdgeAppearance = appearance

        // Kick UIKit to re-layout visible tab bars right now.
        // This avoids needing `.id(colorScheme)` which resets scroll positions.
        refreshVisibleTabBars()
    }

    @MainActor
    private static func refreshVisibleTabBars() {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        for scene in scenes {
            for window in scene.windows {
                guard let root = window.rootViewController else { continue }
                refreshTabBars(in: root)
            }
        }
    }

    @MainActor
    private static func refreshTabBars(in vc: UIViewController) {
        if let tab = vc as? UITabBarController {
            tab.tabBar.setNeedsLayout()
            tab.tabBar.layoutIfNeeded()
        }

        for child in vc.children {
            refreshTabBars(in: child)
        }

        if let presented = vc.presentedViewController {
            refreshTabBars(in: presented)
        }
    }
}
