import SwiftUI

/// Theme + FontPack-aware typography rules.
/// Goal: slick + clean, with distinct "vibes" per theme without sacrificing readability.
struct PBTypography {

    enum Style {
        case classic
        case mint
        case concertHall
        case warm // fallback for the 4th theme (whatever you name it)
    }

    let style: Style
    let fontChoice: PBFontChoice

    // MARK: - Tracking (subtle polish)

    /// Slightly elegant tracking for big headers (kept subtle)
    var heroTracking: CGFloat {
        switch style {
        case .concertHall: return 0.6
        default: return 0.2
        }
    }

    // MARK: - App Title

    /// Big home title (“Practice Buddy”)
    var appTitle: Font {
        // Home title is driven mostly by the selected font pack (playful/elegant)
        fontChoice.homeTitleFont(size: 34)
    }

    // MARK: - Card / Section Titles

    /// Section headers / feature headlines (e.g., “Leaderboards”, “Goal”)
    var sectionTitle: Font {
        fontChoice.headlineFont(weight: .semibold)
    }

    /// Card titles (slightly larger than sectionTitle)
    var cardTitle: Font {
        fontChoice.headlineFont(size: UIFont.preferredFont(forTextStyle: .headline).pointSize + 1, weight: .semibold)
    }

    /// Sheet titles (slightly larger and bolder)
    var sheetTitle: Font {
        fontChoice.headlineFont(size: UIFont.preferredFont(forTextStyle: .title3).pointSize, weight: .bold)
    }

    /// Primary buttons / important labels
    var button: Font {
        // Keep buttons clean and readable
        switch style {
        case .concertHall:
            return .system(.headline, design: .default)
        default:
            // Let font pack nudge it via global fontDesign; keep local style stable
            return .system(.headline, design: .rounded)
        }
    }

    /// Status labels (“Ready / Practicing / Paused”)
    var statusLabel: Font {
        fontChoice.bodyFont()
    }

    /// General body text
    var body: Font {
        fontChoice.bodyFont()
    }

    var footnote: Font {
        .footnote
    }

    // MARK: - Numbers

    /// Large timer
    var timer: Font {
        // Use pack number font (nice consistency everywhere)
        fontChoice.numberFont(size: 28, weight: .bold)
    }

    /// Medium number emphasis (totals, minutes, etc.)
    var number: Font {
        fontChoice.numberFont(size: 16, weight: .semibold)
    }

    // MARK: - Factory

    static func forTheme(_ theme: PBTheme, fontChoice: PBFontChoice) -> PBTypography {
        // Map by your *real* PBTheme IDs:
        // - classic
        // - midnight (Mint)
        // - concert_hall
        // - the 4th theme (whatever you renamed Warm Maple to)
        let style: Style
        switch theme.id {
        case PBTheme.classic.id:
            style = .classic
        case PBTheme.midnight.id:
            style = .mint
        case PBTheme.concertHall.id:
            style = .concertHall
        default:
            style = .warm
        }

        return PBTypography(style: style, fontChoice: fontChoice)
    }
}
