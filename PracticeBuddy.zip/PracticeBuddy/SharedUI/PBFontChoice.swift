import SwiftUI
import UIKit

struct PBFontChoice: Identifiable, Equatable {

    enum Kind: String {
        case systemDefault
        case rounded
        case serif

        // Expressive system fonts we can safely reference by name (may vary by device, so we fallback)
        case snellScript
        case didot
        case georgia
        case avenirNext
        case palatino
        case copperplate
        case gillSans
        case americanTypewriter
        case markerFelt
    }

    // MARK: - Pack roles (font “palette”)

    let id: String
    let name: String

    /// Each pack is a palette of roles that mix well together.
    let titleKind: Kind        // big “Practice Buddy” hero title
    let headlineKind: Kind     // headings / card titles
    let bodyKind: Kind         // body text / notes / general UI copy
    let numberKind: Kind       // numbers / durations / “120 min”

    // Storage key
    static let selectionKey = "pb.settings.fontID"

    // MARK: - Catalog (All FREE)

    static let systemDefault = PBFontChoice(
        id: "font_system_default",
        name: "Standard (System)",
        titleKind: .systemDefault,
        headlineKind: .systemDefault,
        bodyKind: .systemDefault,
        numberKind: .systemDefault
    )

    static let staccatoRounded = PBFontChoice(
        id: "font_rounded",
        name: "Staccato Rounded",
        titleKind: .rounded,
        headlineKind: .rounded,
        bodyKind: .rounded,
        numberKind: .rounded
    )

    static let legatoSerif = PBFontChoice(
        id: "font_serif",
        name: "Legato Serif",
        titleKind: .serif,
        headlineKind: .serif,
        bodyKind: .serif,
        numberKind: .serif
    )

    // Expressive “music-inspired” packs (now free)

    static let concertScript = PBFontChoice(
        id: "font_concert_script",
        name: "Concert Script",
        titleKind: .snellScript,     // playful + elegant
        headlineKind: .palatino,     // refined headings
        bodyKind: .georgia,          // readable body
        numberKind: .avenirNext      // crisp numbers
    )

    static let overtureDidot = PBFontChoice(
        id: "font_overture_didot",
        name: "Overture Didot",
        titleKind: .didot,
        headlineKind: .didot,
        bodyKind: .georgia,
        numberKind: .didot
    )

    static let sonataBook = PBFontChoice(
        id: "font_sonata_book",
        name: "Sonata Book",
        titleKind: .palatino,
        headlineKind: .palatino,
        bodyKind: .georgia,
        numberKind: .palatino
    )

    static let prestoSans = PBFontChoice(
        id: "font_presto_sans",
        name: "Presto Sans",
        titleKind: .avenirNext,
        headlineKind: .avenirNext,
        bodyKind: .avenirNext,
        numberKind: .avenirNext
    )

    static let maestro = PBFontChoice(
        id: "font_maestro_palatino",
        name: "Maestro",
        titleKind: .palatino,
        headlineKind: .palatino,
        bodyKind: .palatino,
        numberKind: .palatino
    )

    static let brassCaps = PBFontChoice(
        id: "font_brass_caps",
        name: "Brass Caps",
        titleKind: .copperplate,
        headlineKind: .copperplate,
        bodyKind: .georgia,          // keep body readable
        numberKind: .copperplate
    )

    static let chamberSans = PBFontChoice(
        id: "font_chamber_sans",
        name: "Chamber Sans",
        titleKind: .gillSans,
        headlineKind: .gillSans,
        bodyKind: .gillSans,
        numberKind: .gillSans
    )

    static let studioType = PBFontChoice(
        id: "font_studio_type",
        name: "Studio Type",
        titleKind: .americanTypewriter,
        headlineKind: .americanTypewriter,
        bodyKind: .georgia,
        numberKind: .americanTypewriter
    )

    static let pizzicato = PBFontChoice(
        id: "font_pizzicato",
        name: "Pizzicato",
        titleKind: .markerFelt,
        headlineKind: .rounded,
        bodyKind: .rounded,
        numberKind: .rounded
    )

    static let all: [PBFontChoice] = [
        systemDefault,
        staccatoRounded,
        legatoSerif,
        concertScript,
        overtureDidot,
        sonataBook,
        prestoSans,
        maestro,
        brassCaps,
        chamberSans,
        studioType,
        pizzicato
    ]

    static func byID(_ id: String) -> PBFontChoice {
        all.first(where: { $0.id == id }) ?? systemDefault
    }

    // MARK: - Global design hint (affects system text styles)

    var globalBodyDesign: Font.Design {
        // Used by `.fontDesign(...)` at app root to nudge all built-in text styles.
        switch bodyKind {
        case .serif, .georgia, .didot, .palatino, .copperplate, .americanTypewriter:
            return .serif
        case .rounded, .markerFelt:
            return .rounded
        default:
            return .default
        }
    }

    // MARK: - Font builders (by role)

    func homeTitleFont(size: CGFloat) -> Font {
        font(for: titleKind, size: size, weight: .bold, preferScript: true)
    }

    func headlineFont(size: CGFloat? = nil, weight: Font.Weight = .semibold) -> Font {
        let s = size ?? UIFont.preferredFont(forTextStyle: .headline).pointSize
        return font(for: headlineKind, size: s, weight: weight, preferScript: false)
    }

    func bodyFont() -> Font {
        let s = UIFont.preferredFont(forTextStyle: .body).pointSize
        // Avoid script for body; keep it readable.
        if bodyKind == .snellScript { return .body }
        return font(for: bodyKind, size: s, weight: .regular, preferScript: false)
    }

    func numberFont(size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        font(for: numberKind, size: size, weight: weight, preferScript: false)
    }

    // MARK: - Internals

    private func font(for kind: Kind, size: CGFloat, weight: Font.Weight, preferScript: Bool) -> Font {
        switch kind {
        case .systemDefault:
            return .system(size: size, weight: weight, design: .default)
        case .rounded:
            return .system(size: size, weight: weight, design: .rounded)
        case .serif:
            return .system(size: size, weight: weight, design: .serif)

        case .snellScript:
            if preferScript {
                return customOrFallback(
                    names: ["SnellRoundhand-Bold", "SnellRoundhand"],
                    size: size,
                    fallback: .system(size: size, weight: .bold, design: .serif)
                )
            } else {
                return .system(size: size, weight: weight, design: .serif)
            }

        case .didot:
            return customOrFallback(
                names: ["Didot-Bold", "Didot"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .serif)
            )

        case .georgia:
            return customOrFallback(
                names: ["Georgia-Bold", "Georgia"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .serif)
            )

        case .avenirNext:
            return customOrFallback(
                names: ["AvenirNext-DemiBold", "AvenirNext-Bold", "AvenirNext-Regular"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .default)
            )

        case .palatino:
            return customOrFallback(
                names: ["Palatino-Bold", "Palatino-Roman", "Palatino"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .serif)
            )

        case .copperplate:
            return customOrFallback(
                names: ["Copperplate-Bold", "Copperplate"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .serif)
            )

        case .gillSans:
            return customOrFallback(
                names: ["GillSans-SemiBold", "GillSans-Bold", "GillSans"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .default)
            )

        case .americanTypewriter:
            return customOrFallback(
                names: ["AmericanTypewriter-Bold", "AmericanTypewriter"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .serif)
            )

        case .markerFelt:
            return customOrFallback(
                names: ["MarkerFelt-Wide", "MarkerFelt-Thin"],
                size: size,
                fallback: .system(size: size, weight: weight, design: .rounded)
            )
        }
    }

    private func customOrFallback(names: [String], size: CGFloat, fallback: Font) -> Font {
        for name in names {
            if UIFont(name: name, size: size) != nil {
                return .custom(name, size: size)
            }
        }
        return fallback
    }
}
